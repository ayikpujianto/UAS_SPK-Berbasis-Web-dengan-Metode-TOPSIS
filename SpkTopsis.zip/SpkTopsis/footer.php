</div> <!-- end container -->

<footer class="bg-dark text-white text-center py-3 fixed-bottom shadow">
  <strong style="font-size:20px;">
    Tugas UAS -= Sistem Pendukung Keputusan =- Ayik Pujianto
  </strong>
</footer>

</body>
</html>
